package com.lti.FarmProject.service;

import java.util.List;

import com.lti.FarmProject.entity.AdminMarket;



public interface AdminMarketService {
	public List<AdminMarket> getAllMarket();
	public AdminMarket getMarketById(Long marketid);
	public boolean saveMarket(AdminMarket market);
	public boolean deleteMarketById(Long marketid);
	public AdminMarket getMarketByLoc(String loc);
	public Boolean updateMarketById(AdminMarket market);
}
