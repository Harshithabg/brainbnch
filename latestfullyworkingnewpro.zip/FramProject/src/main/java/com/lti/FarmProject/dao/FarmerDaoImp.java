package com.lti.FarmProject.dao;

import java.util.List;

import org.springframework.stereotype.Repository;


import com.lti.FarmProject.entity.Farmer;
@Repository("FarmerDao")
public class FarmerDaoImp  extends AbstractDao<Long, Farmer> implements FarmerDao{

	@Override
	public List<Farmer> getAllFarmers() {
		@SuppressWarnings("unchecked")
		List<Farmer> list=getEntityManager().createQuery("SELECT u FROM Farmer u ").getResultList();
		return list;
	}

	@Override
	public Farmer getFarmersById(String farmer_id) {
		Farmer fpr=(Farmer) getEntityManager()
		        .createQuery("SELECT u FROM Farmer u WHERE u.email_id LIKE :Id")
		        .setParameter("Id",farmer_id)
		        .getSingleResult();
				return fpr;
	}

	@Override
	public boolean saveFarmers(Farmer farmer) {
		persist(farmer);
		return true;
	}

	@Override
	public boolean deleteFarmersById(Long farmer_id) {
		Farmer fpr=(Farmer) getEntityManager()
		        .createQuery("SELECT u FROM Farmer u WHERE u.farmer_id LIKE :Id").setParameter("Id", farmer_id)
		        .getSingleResult();
		delete(fpr);
		return true;
	}

	@Override
	public Boolean verifyFarmerbyId(long id, String password) {
		// TODO Auto-generated method stub
		try{
			 getEntityManager()
		        .createQuery("SELECT u FROM Farmer u WHERE u.farmer_id LIKE :"+id+" AND u.fpassword LIKE :"+password)
		        .getSingleResult();
			 return true;
		}catch(Exception e)
		{
			return false;
		}
		
	}

	@Override
	public Boolean updatefarmer(Farmer f) {
		// TODO Auto-generated method stub
		getEntityManager().merge(f);
		return true;
	}

}
