package com.lti.FarmProject.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.FarmProject.dao.InsuranceDao;
import com.lti.FarmProject.entity.Insurance;



@Service
@Transactional
public class InsuranceServiceImpl implements InsuranceService {
	public InsuranceDao dao;
	
	public InsuranceServiceImpl(){
		
	}
	@Autowired
	public InsuranceServiceImpl(InsuranceDao dao) {
		super();
		this.dao = dao;
	}
	/*
	@Autowired
	public InsuranceServiceImpl(InsuranceRepository repository) {
		super();
		this.repository = repository;
	}*/
	
	public List<Insurance> getAllInsurances() {
		List<Insurance> insurancelist= new ArrayList<Insurance>();
		//repository.findAll().forEach(i->insurancelist.add(i));
		insurancelist=dao.getAllInsurances();
		return insurancelist;
	}
	
	public Insurance getInsuranceByPolicy(long policy_no) {
		// TODO Auto-generated method stub
		Insurance insurance=dao.getInsuranceByPolicy(policy_no);//repository.findById(policy_no).get();
		return insurance;
	}

	
	public Boolean saveInsurance(Insurance insurance) {
		// TODO Auto-generated method stub
		try{
			//repository.save(insurance);
			dao.saveInsurance(insurance);
			return true;
		}catch(Exception e){
			return false;
		}
		
	}

	
	public Boolean deleteInsuranceByPolicy(long policy_no) {
		// TODO Auto-generated method stub
		try{
			//repository.deleteById(policy_no);
			dao.deleteInsuranceByPolicy(policy_no);
			return true;
		}catch(Exception e){
			return false;
		}
		
	}
	/*
	public Boolean addClaim(Claim claim) {
		// TODO Auto-generated method stub
		try{
			//claimrep.save(claim);
			dao.addClaim(claim);
			return true;
		}catch(Exception e){
			return false;
		}
		
	}
	
	public Boolean getClaimStatus(long policy_no) {
		// TODO Auto-generated method stub
		//Claim c=claimrep.findById(policy_no).get();
		Boolean status=dao.getClaimStatus(policy_no);
		return status;
	}
	
	public Claim getClaimForm(long policy_no) {
		// TODO Auto-generated method stub
		//Claim c=claimrep.findById(policy_no).get();
		Claim c=dao.getClaimForm(policy_no);
		return c;
	}
	
	public List<Claim> getAllClaims() {
		// TODO Auto-generated method stub
		List<Claim> cl=new ArrayList<Claim>();
		//claimrep.findAll().forEach(c->cl.add(c));
		cl=dao.getAllClaims();
		return cl;
	}
*/
}
