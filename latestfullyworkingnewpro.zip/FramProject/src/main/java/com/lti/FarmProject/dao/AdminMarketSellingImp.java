package com.lti.FarmProject.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.FarmProject.entity.AdminMarketSelling;
@Repository("AdminMarketSellingDao")
public class AdminMarketSellingImp extends AbstractDao<Long,  AdminMarketSelling> implements  AdminMarketSellingDao {

	
	public List<AdminMarketSelling> getAllMarketSelling() {
		@SuppressWarnings("unchecked")
//		List<AdminMarketSelling> list=getEntityManager().createQuery("SELECT u FROM AdminMarketSelling u ").getResultList();
		List<AdminMarketSelling> list=getEntityManager().createQuery("SELECT u FROM AdminMarketSelling u ",AdminMarketSelling.class).getResultList();
		return list;
	}

	
	public AdminMarketSelling getMarketSellingById(Long marketid) {
		AdminMarketSelling ams=(AdminMarketSelling) getEntityManager()
		        .createQuery("SELECT u FROM AdminMarketSelling u WHERE u.msp_id LIKE :Id")
		        .setParameter("Id",marketid)
		        .getSingleResult();
				return ams;
	}

	
	public boolean saveMarketSelling(AdminMarketSelling marketsell) {
		
		persist(marketsell);
		return true;
	}

	
	public boolean deleteMarketSellingById(Long marketid) {
		AdminMarketSelling ams=(AdminMarketSelling) getEntityManager()
		        .createQuery("SELECT u FROM AdminMarketSelling u WHERE u.msp_id LIKE :Id")
		        .setParameter("Id",marketid)
		        .getSingleResult();
		delete(ams);
		return true;
	}


	@Override
	public Boolean updateMarketSellingById(AdminMarketSelling marketsell) {
		try{
			getEntityManager().merge(marketsell);
		}catch(Exception e){
			return false;
		}
		return true;
	}

}
