package com.lti.FarmProject.dao;

import java.util.List;

import com.lti.FarmProject.entity.Insurance;

public interface InsuranceDao{
	public List<Insurance> getAllInsurances();
	public Insurance getInsuranceByPolicy(long policy_no);
	public Boolean saveInsurance(Insurance insurance);
	public Boolean deleteInsuranceByPolicy(long policy_no);
	
}


