package com.lti.FarmProject.dao;

import java.util.List;

import com.lti.FarmProject.entity.AdminMarket;
import com.lti.FarmProject.entity.AdminMarketSelling;

public interface AdminMarketSellingDao {
	public List<AdminMarketSelling> getAllMarketSelling();
	public AdminMarketSelling getMarketSellingById(Long marketid);
	public boolean saveMarketSelling(AdminMarketSelling marketsell);
	public boolean deleteMarketSellingById(Long marketid);
	public Boolean updateMarketSellingById(AdminMarketSelling marketsell);
}
