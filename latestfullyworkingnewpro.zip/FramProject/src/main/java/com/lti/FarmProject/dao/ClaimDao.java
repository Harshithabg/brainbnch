package com.lti.FarmProject.dao;

import java.util.List;

import com.lti.FarmProject.entity.Claim;

public interface ClaimDao {
	public Boolean addClaim(Claim claim);
	public Boolean getClaimStatus(long policy_no);
	public Claim getClaimForm(long policy_no);
	public List<Claim> getAllClaims();
	public Boolean updateclaim(Claim c,Boolean approval);
	public Boolean deleteclaim(long policy_no); 
}
