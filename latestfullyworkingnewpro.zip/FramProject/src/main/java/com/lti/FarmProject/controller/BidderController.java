package com.lti.FarmProject.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lti.FarmProject.entity.Bidder;
//import com.lti.FarmProject.entity.BidderLogin;
//import com.lti.FarmProject.entity.Farmer;
import com.lti.FarmProject.service.BidderService;

@Controller
public class BidderController {
	@Autowired
	private BidderService service;
	

	public BidderController(BidderService service) {
		super();
		this.service = service;
	}
	
	@RequestMapping(value={"/bidderlogin" }, method = RequestMethod.GET)
	public ModelAndView hello(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("bidderlogin");
		return mv;
}
	@RequestMapping(value={"/bidderverify" }, method = RequestMethod.GET)
	public ModelAndView verify(@RequestParam("bidder_id") String id, @RequestParam("bpassword") String password){
	//	ModelAndView mv = new ModelAndView();
		try{Bidder f=service.getBiddersById(id);
			String pass=f.getBpassword();
		
			if(password.equals(pass)){
			ModelAndView mv = new ModelAndView("biddermain");
			mv.setViewName("biddermain");
			
			return mv;
		}else{
			System.out.println("invalid user or password");
			ModelAndView mv1 = new ModelAndView("redirect:/bidderlogin");
		//	mv.setViewName("bidderlogin");
			return mv1;
		}
		}catch(Exception e){
			return new ModelAndView("error");
		}
		//return mv;
}
	@RequestMapping(value={"/BidderRegister"},method=RequestMethod.GET)
	public ModelAndView BidderForm()  {
		ModelAndView mv=new ModelAndView("bidderform");
		mv.addObject("bidder", new Bidder());
		return mv;
		
	}
	@RequestMapping(value={"/saveBidderRegister"},method=RequestMethod.POST)
	public ModelAndView saveBidderForm(@ModelAttribute Bidder bidder,BindingResult result)  {
		ModelAndView mv=new ModelAndView("bidderdocs");
		//mv.addObject("farmer", new Farmer());
		service.saveBidders(bidder)	;
		return mv;
		
	}
	@RequestMapping(value={"/forgotbidderpassword"},method=RequestMethod.GET)
	public ModelAndView showforform(){
		ModelAndView mv= new ModelAndView("bidderforgot");
		return mv;
	}
	@RequestMapping(value={"/changebidderpassword"},method=RequestMethod.GET)
	public ModelAndView updateBidderForm(@RequestParam("id") String id, @RequestParam("bpassword") String pass)  {
		ModelAndView mv=new ModelAndView("bidderlogin");
		String new_id=id;
		String new_pass=pass;
		try{Bidder b=service.getBiddersById(new_id);
		
		b.setBpassword(new_pass);
		service.updatebidder(b);
		//mv.addObject("farmer", new Farmer());
		//service.saveBidders(bidder)	;
		return mv;
		}catch(Exception e){
			return new ModelAndView("error");
		}
		
		
	}
}