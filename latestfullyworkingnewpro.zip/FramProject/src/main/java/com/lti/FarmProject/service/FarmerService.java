package com.lti.FarmProject.service;

import java.util.List;

import com.lti.FarmProject.entity.Farmer;

public interface FarmerService {
	public List<Farmer> getAllFarmers();
	public Farmer getFarmersById(String farmer_id);
	public boolean saveFarmers(Farmer farmer);
	public boolean deleteFarmersById(Long farmer_id);
	public Boolean verifyfarmerbyId(long id,String password);
	public Boolean updatefarmer(Farmer f);
}
