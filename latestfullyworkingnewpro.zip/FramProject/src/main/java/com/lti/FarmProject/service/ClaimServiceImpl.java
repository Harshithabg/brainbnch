package com.lti.FarmProject.service;

import java.util.ArrayList;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.FarmProject.dao.ClaimDao;
import com.lti.FarmProject.entity.Claim;


@Service
@Transactional
public class ClaimServiceImpl implements ClaimService{
	
	private ClaimDao dao;
	
	@Autowired
	public ClaimServiceImpl(ClaimDao dao) {
		super();
		this.dao = dao;
	}

	//@Override
	public Boolean addClaim(Claim claim) {
		// TODO Auto-generated method stub
		Boolean as=dao.addClaim(claim);
		return as;
	}

	//@Override
	public Boolean getClaimStatus(long policy_no) {
		// TODO Auto-generated method stub
		Boolean cs=dao.getClaimStatus(policy_no);
		return cs;
	}

	//@Override
	public Claim getClaimForm(long policy_no) {
		// TODO Auto-generated method stub
		Claim c=dao.getClaimForm(policy_no);
		return c;
	}

	//@Override
	public List<Claim> getAllClaims() {
		// TODO Auto-generated method stub
		List<Claim> cl=new ArrayList<Claim>();
		cl=dao.getAllClaims();
		return cl;
	}

	@Override
	public Boolean updateclaim(Claim c, Boolean approval) {
		// TODO Auto-generated method stub
		Boolean s=dao.updateclaim(c, approval);
		return s;
	}

	@Override
	public Boolean deleteclaim(long policy_no) {
		// TODO Auto-generated method stub
		Boolean s=dao.deleteclaim(policy_no);
		return s;
	}

}
