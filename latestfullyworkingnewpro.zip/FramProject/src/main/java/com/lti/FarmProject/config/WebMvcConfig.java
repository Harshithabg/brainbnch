package com.lti.FarmProject.config;

import org.springframework.context.annotation.Bean;
//import org.springframework.context.MessageSource;
//import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
//import org.springframework.context.annotation.Import;
//import org.springframework.context.support.ResourceBundleMessageSource;
//import org.springframework.validation.Validator;
//import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = "com.lti.FarmProject")
public class WebMvcConfig implements WebMvcConfigurer {


	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/resources/**").
		addResourceLocations("/resources/css");
	}

	public void configureViewResolvers(ViewResolverRegistry registry) {
		registry.jsp().prefix("/WEB-INF/views/").suffix(".jsp");
	}
	public void addViewControllers(ViewControllerRegistry registry) {
		registry.addViewController("/").setViewName("newhome");
	}
/*	public void addViewControllers1(ViewControllerRegistry registry) {
		registry.addViewController("/").setViewName("adminhome");
	}
	public void addViewControllers2(ViewControllerRegistry registry) {
		registry.addViewController("/").setViewName("adminsell");
	}
*/
	 
}
