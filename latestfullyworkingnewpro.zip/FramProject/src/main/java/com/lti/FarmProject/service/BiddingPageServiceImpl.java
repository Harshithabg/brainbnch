package com.lti.FarmProject.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.FarmProject.dao.BiddingPageDao;
import com.lti.FarmProject.entity.BiddingPage;

@Service
@Transactional
public class BiddingPageServiceImpl implements BiddingPageService {
	private BiddingPageDao dao;

	public BiddingPageServiceImpl() {
		super();
	}

	@Autowired
	public BiddingPageServiceImpl(BiddingPageDao dao) {
		super();
		this.dao = dao;
	}

	@Override
	public BiddingPage pageByRequestId(long request_id) {
		// TODO Auto-generated method stub
		BiddingPage page=dao.pageByRequestId(request_id);
		return page;
	}

	@Override
	public Boolean addBiddingPage(BiddingPage biddingpage) {
		// TODO Auto-generated method stub
		Boolean status=dao.addBiddingPage(biddingpage);
		return status;
	}

	@Override
	public Boolean updateBiddingPage(BiddingPage biddingpage) {
		// TODO Auto-generated method stub
		Boolean status=dao.updateBiddingPage(biddingpage);
		return status;
	}

	@Override
	public List<BiddingPage> getallbids() {
		// TODO Auto-generated method stub
		List<BiddingPage> bl=dao.getallbids();
		return bl;
	}

	@Override
	public BiddingPage getbidbyid(long id) {
		// TODO Auto-generated method stub
		BiddingPage b=dao.getbidbyid(id);
		return b;
	}

	@Override
	public List<BiddingPage> getallfinalbids() {
		// TODO Auto-generated method stub
		List<BiddingPage> bl=dao.getallfinalbids();
		return bl;
	}

}

