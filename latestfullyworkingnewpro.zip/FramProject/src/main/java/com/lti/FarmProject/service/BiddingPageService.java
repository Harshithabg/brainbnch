package com.lti.FarmProject.service;

import java.util.List;

import com.lti.FarmProject.entity.BiddingPage;

public interface BiddingPageService {
	public BiddingPage pageByRequestId(long request_id);
	public Boolean addBiddingPage(BiddingPage biddingpage);
	public Boolean updateBiddingPage(BiddingPage biddingpage);
	public List<BiddingPage> getallbids();
	public BiddingPage getbidbyid(long id);
	public List<BiddingPage> getallfinalbids();
}
