package com.lti.FarmProject.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.FarmProject.dao.FarmerDao;
import com.lti.FarmProject.entity.Farmer;


@Service
@Transactional
public class FarmerServiceImp implements FarmerService{

private FarmerDao dao;
	
	public FarmerServiceImp() {
		
	}
	
	@Autowired
	public FarmerServiceImp(FarmerDao dao) {
		super();
		this.dao = dao;
	}
	@Override
	public List<Farmer> getAllFarmers() {
		List<Farmer> list = new ArrayList<Farmer>();
		list=dao.getAllFarmers();
		return list;
	}

	@Override
	public Farmer getFarmersById(String farmer_id) {
		Farmer farmer =  dao.getFarmersById(farmer_id);
		return farmer;
	}

	@Override
	public boolean saveFarmers(Farmer farmer) {
		try {
			dao.saveFarmers(farmer);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

	@Override
	public boolean deleteFarmersById(Long farmer_id) {
		try {
			dao.deleteFarmersById(farmer_id);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

	@Override
	public Boolean verifyfarmerbyId(long id, String password) {
		// TODO Auto-generated method stub
		dao.verifyFarmerbyId(id, password);
		return null;
	}

	@Override
	public Boolean updatefarmer(Farmer f) {
		// TODO Auto-generated method stub
		dao.updatefarmer(f);
		return true;
	}

}
