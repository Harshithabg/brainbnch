package com.lti.FarmProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lti.FarmProject.entity.BiddingPage;
import com.lti.FarmProject.entity.FarmerPlaceRequest;
import com.lti.FarmProject.service.BiddingPageService;
import com.lti.FarmProject.service.FarmerPlaceRequestService;

@Controller
public class BiddingPageController {
	@Autowired
	private BiddingPageService service;
	@Autowired
	private FarmerPlaceRequestService userService;
	
	public BiddingPageController() {
		super();
	}

	public BiddingPageController(BiddingPageService service) {
		super();
		this.service = service;
	}
	
	public BiddingPageController(FarmerPlaceRequestService userService) {
		super();
		this.userService = userService;
	}
	long req_id;
	BiddingPage bidding;
	FarmerPlaceRequest fpm;
	@RequestMapping(value="/bidderhome",method=RequestMethod.GET)
	public ModelAndView getBindingPage(){
		ModelAndView mv=new ModelAndView("bidderhome");
		List<FarmerPlaceRequest> sellreq= userService.getAllPlaceRequest();
		mv.addObject("sellreq",sellreq);
		return mv;
	}
	
	@RequestMapping(value="/savebidding",method=RequestMethod.POST)
	public ModelAndView postBindingPage(@ModelAttribute BiddingPage biddingpage, BindingResult result){
		ModelAndView mv=new ModelAndView("redirect:/bidderhome");
		if (result.hasErrors()) {
			return new ModelAndView("error");
		}
//		long cb=service.getCurrentBid(bidding);
		long cb=bidding.getCurrent_bid();
		long bid=biddingpage.getBid_your_amount();
		String bid_crop_name=fpm.getCropname();
		 long bid_quantity=fpm.getQuantity();
		 String bid_crop_type=fpm.getCrop_type();
		 long bid_price=fpm.getPrice();
		 long bid_requestid=fpm.getRequestid();
		 //System.out.println(bid_crop_name);
		long base=bidding.getBid_price();
		Boolean fb=false;
		System.out.println(base);
		System.out.println(cb+" n "+bid);
		if(cb==0 && base<bid){
			//bidding.setCurrent_bid(cb);
			 bidding=new BiddingPage( bid_crop_type, bid_requestid, bid_quantity, bid_price,bid_crop_name,bid,bid,fb);
		boolean isAdded = service.addBiddingPage(bidding);
		if (isAdded) {
			System.out.println(bidding);
			mv.addObject("message", "Applied successfully");
			
		} else {
			return new ModelAndView("error");
		}
		//mv.addObject("bidding",new BiddingPage());
		
		}else if(cb==0 && base>bid){
			bidding=new BiddingPage( bid_crop_type, bid_requestid, bid_quantity, bid_price,bid_crop_name,bid,base);
			boolean isAdded = service.addBiddingPage(bidding);
		}else if(cb<bid){
			 bidding=new BiddingPage( bid_crop_type, bid_requestid, bid_quantity, bid_price,bid_crop_name,bid,bid);
			//bidding.setCurrent_bid(bid);
			service.updateBiddingPage(bidding);
			
			}
		return mv;
	}
	@RequestMapping(value="/gotopagebyid",method=RequestMethod.GET)
	public ModelAndView getPageOnRequest(){  	//@ModelAttribute BiddingPage biddingpage, BindingResult result
		ModelAndView mv=new ModelAndView("biddingpage");
		System.out.println("inside getpagebyid"+fpm);
		 String bid_crop_name=fpm.getCropname();
		 long bid_quantity=fpm.getQuantity();
		 String bid_crop_type=fpm.getCrop_type();
		 long bid_price=fpm.getPrice();
		 long bid_requestid=fpm.getRequestid();
		 System.out.println(bid_crop_name);
		 bidding=new BiddingPage( bid_crop_type, bid_requestid, bid_quantity, bid_price,bid_crop_name);
//		biddingpage.setBid_crop_name(cropname);
//		
//		biddingpage.setBid_crop_type(croptype);
//		
//		biddingpage.setBid_price(price);
//		
//		biddingpage.setBid_quantity(q);
		//service.addBiddingPage(biddingpage);
		mv.addObject("biddingpage",bidding);
		
		return mv;
		
	}
	@RequestMapping(value = "/editpage/{requestid}", method = RequestMethod.GET)
	public ModelAndView displayEditUserForm(@PathVariable long requestid) {
		ModelAndView mv = new ModelAndView("redirect:/gotopagebyid");
		FarmerPlaceRequest request = userService.getPlaceRequestById(requestid);
		
		fpm=request;
		System.out.println(fpm);
		//mv.addObject("headerMessage", "Edit User Details");
		//mv.addObject("biddingpage", biddingpage);
		//mv.setViewName("getpagebyid");
		return mv;
	}	

	/*
	@RequestMapping(value="/getpagebyid/{requestid}",method=RequestMethod.POST)
	public ModelAndView postPageOnRequest(@ModelAttribute FarmerPlaceRequest request,BindingResult result){
		ModelAndView mv=new ModelAndView("");
		
		return mv;
		
	}*/
	@RequestMapping(value="/viewsoldhistory",method=RequestMethod.GET)
	public ModelAndView viewsoldhistory(){
		ModelAndView mv= new ModelAndView("viewsoldhistory");
		List<BiddingPage> bl=service.getallfinalbids();
		mv.addObject("soldhistory", bl);
		mv.setViewName("viewsoldhistory");
		return mv;
	}
	

}
