package com.lti.FarmProject.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lti.FarmProject.entity.BiddingPage;
@Repository("BiddingPageDao")
public class BiddingPageDaoImpl extends AbstractDao<Long,BiddingPage> implements BiddingPageDao{

	//@Override
	public BiddingPage pageByRequestId(long request_id) {
		// TODO Auto-generated method stub
		BiddingPage bp=(BiddingPage) getEntityManager()
                .createQuery("SELECT u FROM BiddingPage u WHERE u.bid_requestid LIKE :Id")
                .setParameter("Id",request_id)
                .getSingleResult();
		return bp;
	}

	//@Override
	public Boolean addBiddingPage(BiddingPage biddingpage) {
		// TODO Auto-generated method stub
		persist(biddingpage);
		return true;
	}

	//@Override
	public Boolean updateBiddingPage(BiddingPage biddingpage) {
		// TODO Auto-generated method stub
		getEntityManager().merge(biddingpage);
		return true;
	}

	@Override
	public List<BiddingPage> getallbids() {
		// TODO Auto-generated method stub
		List<BiddingPage> bidlist=getEntityManager().createQuery("SELECT u FROM BiddingPage u ").getResultList();
		return bidlist;
	}

	@Override
	public BiddingPage getbidbyid(long id) {
		// TODO Auto-generated method stub
		BiddingPage b= (BiddingPage) getEntityManager()
                .createQuery("SELECT u FROM BiddingPage u WHERE u.bid_id LIKE :Id")
                .setParameter("Id",id)
                .getSingleResult();
		return b;
	}

	@Override
	public List<BiddingPage> getallfinalbids() {
		// TODO Auto-generated method stub
		List<BiddingPage> bidlist=getEntityManager().createQuery("SELECT u FROM BiddingPage u WHERE u.finalbid LIKE :Id").setParameter("Id", true).getResultList();
		return bidlist;
	}

}
