package com.lti.FarmProject.service;

import java.util.List;

import com.lti.FarmProject.entity.Bidder;
//import com.lti.FarmProject.entity.BiddingPage;

public interface BidderService {
	public List<Bidder> getAllBidders();
	public Bidder getBiddersById(String bidder_id);
	public boolean saveBidders(Bidder bidder);
	public boolean deleteBiddersById(Long bidder_id);
	public Boolean verifybidderbyId(long id,String password);
	public Boolean updatebidder(Bidder b);
	
}
