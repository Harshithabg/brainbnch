package com.lti.FarmProject.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.FarmProject.dao.AdminMarketDao;
import com.lti.FarmProject.entity.AdminMarket;

@Service
@Transactional
public class AdminMarketServiceImp implements AdminMarketService {
private AdminMarketDao dao;
	
	public AdminMarketServiceImp() {
		
	}
	
	@Autowired
	public AdminMarketServiceImp(AdminMarketDao dao) {
		super();
		this.dao = dao;
	}
	
	@Override
	public List<AdminMarket> getAllMarket() {
		List<AdminMarket> list = new ArrayList<AdminMarket>();
		list=dao.getAllMarket();
		return list;
		
	}

	@Override
	public AdminMarket getMarketById(Long marketid) {
		AdminMarket market =  dao.getMarketById(marketid);
		return market;
	}

	@Override
	public boolean saveMarket(AdminMarket market) {
		try {
			dao.saveMarket(market);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

	@Override
	public boolean deleteMarketById(Long marketid) {
		try {
			dao.deleteMarketById(marketid);
			return true;
		}catch(Exception ex) {
			return false;
		}
	}

	@Override
	public AdminMarket getMarketByLoc(String loc) {
		// TODO Auto-generated method stub
		AdminMarket am=dao.getMarketByLoc(loc);
		return am;
	}

	@Override
	public Boolean updateMarketById(AdminMarket market) {
		// TODO Auto-generated method stub
		Boolean stat=dao.updateMarketById(market);
		return stat;
	}

}
